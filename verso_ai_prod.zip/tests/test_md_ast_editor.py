import md_ast_editor

def test_update_existing_section():
    md = """# Title

## Overview
Old

## Architecture
Arch
"""
    updated = md_ast_editor.update_section(md, 'Overview', 'New content')
    assert 'New content' in updated
    assert 'Old' not in updated

def test_append_section():
    md = "# Title\n\nSome intro\n"
    updated = md_ast_editor.update_section(md, 'NewSection', 'Content here')
    assert 'Content here' in updated
