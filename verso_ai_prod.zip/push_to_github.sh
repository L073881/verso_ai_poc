#!/usr/bin/env bash
set -e

BRANCH=verso-ai-initial-scaffold
git checkout -b $BRANCH
git add .
git commit -m "chore: add verso_ai production scaffold"
if [ -n "$GITHUB_TOKEN" ]; then
  echo "Using GITHUB_TOKEN to push"
  git remote set-url origin https://${GITHUB_TOKEN}@github.com/$(git remote get-url origin | sed -e 's#.*github.com/##')
fi
git push -u origin $BRANCH
echo "Pushed branch $BRANCH"
