import re
from typing import Tuple
import difflib

REQUIRED_HEADINGS = ["Overview", "Architecture", "APIs", "Data Model", "Sequence Flow", "Deployment", "Ownership"]

def validate_markdown_basic(md: str) -> Tuple[bool, list]:
    issues = []
    if not md or not md.strip():
        issues.append("Document is empty")
        return False, issues

    text = md.lower()
    for h in REQUIRED_HEADINGS:
        if h.lower() not in text:
            issues.append(f"Missing heading: {h}")

    if len(md) > 200_000:
        issues.append("Document too large (>200k chars)")

    return (len(issues) == 0), issues

def markdown_diff_preview(old: str, new: str, max_lines: int = 50) -> str:
    old_lines = old.splitlines()
    new_lines = new.splitlines()
    diff = difflib.unified_diff(old_lines, new_lines, lineterm="")
    lines = list(diff)
    if not lines:
        return "No differences."
    preview = "\n".join(lines[:max_lines])
    return f"```diff\n{preview}\n```"
