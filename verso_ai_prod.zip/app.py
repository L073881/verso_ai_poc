import os
import json
import logging
from typing import Optional, Dict, Any, List

from fastapi import FastAPI, Request, Header, HTTPException
from pydantic import BaseModel
from dotenv import load_dotenv

from cortex_client import CortexClient
from git_utils import GitHubRepo
from prompts import CREATE_PROMPT, UPDATE_PROMPT, TEMPLATE_EXTRACT_PROMPT
from validator import validate_markdown_basic, markdown_diff_preview
from md_ast_editor import update_section

load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("verso_ai")

# Basic environment/config
CORTEX_BASE = os.getenv("CORTEX_BASE", "").rstrip("/")
CORTEX_USER = os.getenv("CORTEX_USER")
CORTEX_MODEL = os.getenv("CORTEX_MODEL", "verso_doc_model")
CORTEX_DATASET = os.getenv("CORTEX_DATASET", "verso_docs_dataset")

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
GITHUB_REPO = os.getenv("GITHUB_REPO")
BRANCH_PREFIX = os.getenv("BRANCH_PREFIX", "verso-ai")
SIMILARITY_THRESHOLD = float(os.getenv("SIMILARITY_THRESHOLD", "0.65"))

JIRA_BASE = os.getenv("JIRA_BASE")
JIRA_USER = os.getenv("JIRA_USER")
JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN")
BOT_COMMITTER_NAME = os.getenv("BOT_COMMITTER_NAME", "verso-ai")
BOT_COMMITTER_EMAIL = os.getenv("BOT_COMMITTER_EMAIL", "verso-ai@example.com")

cortex = CortexClient(base_url=CORTEX_BASE)
gh = GitHubRepo(token=GITHUB_TOKEN, repo_full_name=GITHUB_REPO)

app = FastAPI(title="verso-ai-agent")

class JiraWebhookPayload(BaseModel):
    issue: Dict[str, Any]
    comment: Dict[str, Any]

def branch_for_ticket(ticket_key: str) -> str:
    safe = ticket_key.replace("/", "-").lower()
    return f"{BRANCH_PREFIX}-{safe}-doc"

def comment_on_jira(issue_key: str, body: str):
    url = f"{JIRA_BASE}/rest/api/2/issue/{issue_key}/comment"
    import requests
    auth = (JIRA_USER, JIRA_API_TOKEN)
    headers = {"Content-Type": "application/json"}
    resp = requests.post(url, auth=auth, headers=headers, json={"body": body})
    if resp.status_code not in (200, 201):
        logger.error("Jira comment failed: %s %s", resp.status_code, resp.text)
        raise Exception("Jira comment failed")
    return resp.json()

def decide_action(matches: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not matches:
        return {"action": "create", "match": None}
    best = max(matches, key=lambda m: m.get("score", m.get("similarity", 0)))
    score = best.get("score", best.get("similarity", 0))
    logger.info("Best similarity score: %s", score)
    if score >= SIMILARITY_THRESHOLD:
        return {"action": "update", "match": best}
    return {"action": "create", "match": best}

@app.post("/webhook/jira")
async def jira_webhook(request: Request, x_event_key: Optional[str] = Header(None)):
    payload_raw = await request.json()
    try:
        payload = JiraWebhookPayload(**payload_raw)
    except Exception as e:
        logger.exception("Invalid payload: %s", e)
        raise HTTPException(status_code=400, detail="invalid payload")

    issue = payload.issue
    comment = payload.comment

    ticket_key = issue.get("key")
    fields = issue.get("fields", {}) or {}
    summary = fields.get("summary", "")
    description = fields.get("description", "") or ""
    comment_text = comment.get("body", "") or ""

    logger.info("Received Jira event for %s — comment: %s", ticket_key, comment_text)

    if "@verso_ai" not in comment_text.lower():
        logger.info("No mention of @verso_ai — ignoring.")
        return {"status": "ignored"}

    try:
        result = process_ticket(ticket_key, summary, description, comment_text)
    except Exception as e:
        logger.exception("Processing failed")
        try:
            comment_on_jira(ticket_key, f"verso_ai: processing failed: {str(e)}")
        except Exception:
            logger.exception("Failed to post failure to Jira")
        raise HTTPException(status_code=500, detail=str(e))

    comment_on_jira(ticket_key, result["jira_comment"])
    return {"status": "ok", "pr": result.get("pr_url")}

def process_ticket(ticket_key: str, summary: str, description: str, comment: str) -> Dict[str, Any]:
    # 1) search for matching doc chunks in Cortex dataset
    search_text = f"{summary}\n{description}\n{comment}"
    logger.info("Searching Cortex dataset for similar docs...")
    search_resp = cortex.search_dataset(query=search_text, dataset_name=CORTEX_DATASET, top_k=5)
    matches = search_resp.get("results") or search_resp.get("matches") or []

    decision = decide_action(matches)
    logger.info("Decision: %s", decision["action"])

    branch = branch_for_ticket(ticket_key)
    pr_url = None

    if decision["action"] == "update":
        match = decision["match"]
        metadata = match.get("metadata", {})
        repo_path = metadata.get("file_path") or metadata.get("repo_path")
        context_text = "\n\n".join(m.get("text", "") for m in matches if m.get("text"))
        prompt = UPDATE_PROMPT.format(existing_sections=context_text,
                                      ticket_summary=summary,
                                      ticket_description=description,
                                      ticket_key=ticket_key)
        logger.info("Asking Cortex to generate updated doc...")
        gen = cortex.ask_model(model_name=CORTEX_MODEL, prompt=prompt, context=context_text)
        updated_md = gen.get("message") or gen.get("text") or ""
        target_heading = (metadata.get("chunk_heading") or metadata.get("heading") or "Overview")
        try:
            current_content = gh.get_file_contents(repo_path, ref=gh.default_branch) if repo_path else ""
        except Exception:
            current_content = ""
        patched_md = update_section(current_content or updated_md, target_heading, updated_md)
        valid, issues = validate_markdown_basic(patched_md)
        if not valid:
            jira_msg = f"verso_ai: Generated document failed validation: {issues}. Created WIP PR for manual review."
            pr_url = gh.create_pr_with_content(path=repo_path or f"docs/{ticket_key}_design.md",
                                              content=patched_md,
                                              branch=branch,
                                              title=f"[verso_ai] Update design doc for {ticket_key}",
                                              body="Auto-generated update — please review. Validation issues: " + str(issues),
                                              committer={"name": BOT_COMMITTER_NAME, "email": BOT_COMMITTER_EMAIL})
            return {"pr_url": pr_url, "jira_comment": jira_msg}
        pr_url = gh.create_pr_with_content(path=repo_path or f"docs/{ticket_key}_design.md",
                                          content=patched_md,
                                          branch=branch,
                                          title=f"[verso_ai] Update design doc for {ticket_key}",
                                          body=f"Auto-generated update for {ticket_key} by verso_ai.")
        jira_comment = f"verso_ai: Created PR for updating document: {pr_url}"
        try:
            current = gh.get_file_contents(repo_path, ref=gh.default_branch) if repo_path else ""
            diff_preview = markdown_diff_preview(current or "", patched_md)
            jira_comment += f"\n\nDiff preview:\n\n{diff_preview}"
        except Exception:
            pass
        return {"pr_url": pr_url, "jira_comment": jira_comment}

    # else create
    logger.info("No sufficient match found — creating new design document.")
    examples_resp = cortex.get_dataset_examples(dataset_name=CORTEX_DATASET, limit=5)
    examples = examples_resp.get("examples", [])
    tpl_prompt = TEMPLATE_EXTRACT_PROMPT.format(examples=json.dumps(examples))
    tpl_gen = cortex.ask_model(model_name=CORTEX_MODEL, prompt=tpl_prompt)
    tp_text = tpl_gen.get("message") or tpl_gen.get("text") or "{}"
    try:
        template_profile = json.loads(tp_text)
    except Exception:
        template_profile = {}

    create_prompt = CREATE_PROMPT.format(template_profile=json.dumps(template_profile),
                                         ticket_summary=summary,
                                         ticket_description=description,
                                         ticket_key=ticket_key)
    gen = cortex.ask_model(model_name=CORTEX_MODEL, prompt=create_prompt)
    new_md = gen.get("message") or gen.get("text") or ""
    valid, issues = validate_markdown_basic(new_md)
    if not valid:
        pr_url = gh.create_pr_with_content(path=f"docs/{ticket_key}_design.md",
                                          content=new_md,
                                          branch=branch,
                                          title=f"[verso_ai] New design doc for {ticket_key} (WIP)",
                                          body=f"Auto-generated doc (WIP). Validation issues: {issues}",
                                          committer={"name": BOT_COMMITTER_NAME, "email": BOT_COMMITTER_EMAIL})
        jira_comment = f"verso_ai: Created WIP PR for new design doc: {pr_url}\nValidation issues: {issues}"
        return {"pr_url": pr_url, "jira_comment": jira_comment}

    pr_url = gh.create_pr_with_content(path=f"docs/{ticket_key}_design.md",
                                      content=new_md,
                                      branch=branch,
                                      title=f"[verso_ai] Auto-generated design doc for {ticket_key}",
                                      body=f"Auto-created design doc for {ticket_key} via verso_ai.")
    jira_comment = f"verso_ai: Created design doc and PR: {pr_url}"
    return {"pr_url": pr_url, "jira_comment": jira_comment}
