# Verso AI Automatic Design Document Agent (Production-ready scaffold)

This repository contains a production-ready scaffold for the Verso AI agent that:
- Receives Jira webhook comments
- Uses Cortex (LIGHT client) for RAG and generation
- Edits or creates Markdown design documents in GitHub
- Opens PRs and comments back on Jira

## Quickstart (local)
1. Copy `.env.example` to `.env` and fill credentials.
2. Create virtualenv and install:
   ```
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
3. Run the app:
   ```
   uvicorn app:app --reload --port 8080
   ```
4. Expose to Jira (ngrok) or POST test payload to `/webhook/jira`.

## Files of interest
- `app.py` – main FastAPI application
- `cortex_client.py` – wrapper for LIGHT client calls
- `git_utils.py` – GitHub helpers (PyGithub)
- `md_ast_editor.py` – safe markdown section editor
- `validator.py` – basic validation and diff preview
- `prompts.py` – generation prompts
- `tests/` – unit tests
- `Dockerfile` – for container deploy

## Security
Store secrets in your secret manager (AWS Secrets Manager, ECS task defs). Do not commit `.env` to repo.
