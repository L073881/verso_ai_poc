import re

def split_by_headings(md: str):
    lines = md.splitlines()
    sections = []
    current_heading = None
    current_level = 0
    buffer = []

    def flush():
        nonlocal current_heading, current_level, buffer
        content = "\n".join(buffer).rstrip() + ("\n" if buffer else "")
        if current_heading is None:
            sections.append((0, None, content))
        else:
            sections.append((current_level, current_heading, content))
        buffer = []

    for ln in lines:
        m = re.match(r'^(#{1,6})\s+(.*)$', ln)
        if m:
            if buffer or current_heading is not None:
                flush()
            current_level = len(m.group(1))
            current_heading = m.group(2).strip()
            buffer = [ln]
        else:
            buffer.append(ln)
    if buffer or current_heading is not None:
        flush()
    return sections

def update_section(md: str, target_heading: str, new_section_md: str) -> str:
    sections = split_by_headings(md)
    out = []
    replaced = False
    for level, heading, content in sections:
        if heading and heading.lower() == target_heading.lower() and not replaced:
            heading_line = '#' * level + ' ' + heading if level > 0 else ''
            if heading_line:
                out.append(heading_line)
                out.append(new_section_md.rstrip())
            else:
                out.append(new_section_md.rstrip())
            replaced = True
        else:
            out.append(content.rstrip())
    if not replaced:
        out.append('\n\n' + new_section_md.rstrip())
    joined = '\n\n'.join(s for s in out if s is not None and s != "")
    return joined + '\n'
