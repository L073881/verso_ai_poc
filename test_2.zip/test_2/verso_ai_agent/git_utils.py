# git_utils.py
from github import Github
import logging

logger = logging.getLogger("git_utils")

class GitHubRepo:
    def __init__(self, token: str, repo_full_name: str):
        self.gh = Github(token)
        self.repo = self.gh.get_repo(repo_full_name)
        self.default_branch = self.repo.default_branch

    def create_branch(self, branch_name: str):
        master = self.repo.get_branch(self.default_branch)
        try:
            self.repo.create_git_ref(ref=f"refs/heads/{branch_name}", sha=master.commit.sha)
            logger.info("Created branch %s", branch_name)
        except Exception as e:
            logger.warning("Could not create branch (may exist): %s", e)

    def create_or_update_file(self, path: str, content: str, branch: str, commit_message: str, committer: dict):
        # check if exists on branch
        try:
            file = self.repo.get_contents(path, ref=branch)
            self.repo.update_file(path, commit_message, content, file.sha, branch=branch, committer=committer)
            logger.info("Updated file %s on branch %s", path, branch)
        except Exception:
            self.repo.create_file(path, commit_message, content, branch=branch, committer=committer)
            logger.info("Created file %s on branch %s", path, branch)

    def create_pr_with_content(self, path: str, content: str, branch: str, title: str, body: str, committer: dict = None):
        # branch
        self.create_branch(branch)
        if committer is None:
            committer = {"name": "verso-ai", "email": "verso-ai@example.com"}
        self.create_or_update_file(path=path, content=content, branch=branch, commit_message=title, committer=committer)
        pr = self.repo.create_pull(title=title, body=body, head=branch, base=self.default_branch)
        return pr.html_url

    def get_file_contents(self, path: str, ref: str = None):
        reference = ref or self.default_branch
        try:
            file = self.repo.get_contents(path, ref=reference)
            return file.decoded_content.decode("utf-8")
        except Exception:
            return ""
