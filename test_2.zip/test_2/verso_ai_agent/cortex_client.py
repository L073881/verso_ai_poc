# cortex_client.py
import os
import logging
from typing import Dict, Any
from light_client import LIGHTClient

logger = logging.getLogger("cortex_client")

CORTEX_BASE = os.getenv("CORTEX_BASE", "").rstrip("/")
light = LIGHTClient()  # uses environment / AWS auth per LIGHT client docs

class CortexClient:
    def __init__(self, base_url: str = CORTEX_BASE):
        self.base = base_url.rstrip("/")
        self.client = light

    def search_dataset(self, query: str, dataset_name: str, top_k: int = 5) -> Dict[str, Any]:
        """
        Use Cortex search endpoint to find relevant chunks in the dataset.
        The exact endpoint can vary by install; adapt if your Cortex API uses different path.
        """
        # Prefer /data/search or /model/search depending on deployment. Try model/search first.
        try:
            resp = self.client.post(f"{self.base}/model/search", json={"q": query, "data_config": dataset_name, "top_k": top_k})
            if resp.status_code == 200:
                return resp.json()
        except Exception as e:
            logger.warning("model/search failed: %s", e)
        # fallback to /data/search
        resp = self.client.post(f"{self.base}/data/search", json={"q": query, "data_config": dataset_name, "top_k": top_k})
        resp.raise_for_status()
        return resp.json()

    def ask_model(self, model_name: str, prompt: str, context: str = None) -> Dict[str, Any]:
        """
        Call the configured Cortex model (model/ask/<model_name>) with prompt + optional context.
        """
        payload = {"q": prompt}
        if context:
            payload["context"] = context
        resp = self.client.post(f"{self.base}/model/ask/{model_name}", data=payload)
        resp.raise_for_status()
        return resp.json()

    def get_dataset_examples(self, dataset_name: str, limit: int = 5) -> Dict[str, Any]:
        try:
            resp = self.client.get(f"{self.base}/data/examples/{dataset_name}")
            resp.raise_for_status()
            return resp.json()
        except Exception:
            return {"examples": []}
